# APTUS — Inteligência de Propostas Técnicas Comprováveis

**HackatOhm 2026 | D03 — EloGroup | Projeto APTUS | Equipe: [conferir cadastro]**  
**Integrantes:** preencher nomes e demais identificadores exigidos pelo modelo oficial.  
**Vídeo-pitch:** inserir o link público/não listado após a gravação e conferir o acesso como visitante.

## 1. Problema e diagnóstico

A Nexora, consultoria fictícia do desafio com mais de 1.000 profissionais, precisa encontrar rapidamente a equipe mais aderente a cada disputa, apresentar sua experiência e manter os currículos atualizados. Hoje, arquivos dispersos, formatos diferentes, dados antigos e comprovantes ausentes fazem talentos passarem despercebidos. O case estima 40 disputas anuais, com 15–25 horas agregadas de gestores por disputa: **600–1.000 horas por ano** [1]. A falta de prova também pode impedir classificação: em uma concorrência real da AMEP-PR, o coordenador indicado somou 6 pontos, abaixo do mínimo obrigatório de 8 [2]. O problema é, portanto, de informação, processo e admissibilidade — não apenas de busca textual.

## 2. Solução e contribuição original

O Aptus organiza **uma base viva de competências e evidências**, interpreta requisitos sob revisão humana, compõe equipes admissíveis e produz um dossiê auditável da equipe-chave. Cada ponto é ligado à regra, ao profissional e à prova que o sustenta. Quatro dimensões permanecem separadas: alegação do profissional, verificação da evidência, validade na data exigida e aceitação específica para o edital. Uma certificação apenas mencionada não pontua; informação ausente permanece desconhecida.

O diferencial **Aptus Recovery** identifica provas recuperáveis antes do prazo — como atestados de projetos já realizados — e mostra seu impacto na equipe inteira. Não inventa experiência nem soma pontos potenciais como confirmados. Base Viva, Recovery e Dossiê formam um ciclo: cada disputa melhora a organização e a atualização do acervo.

## 3. Lógica de escolha, tecnologia e operação

O fluxo é: edital/anexos → matriz aprovada por Licitações → busca exata e semântica → elegibilidade e pontuação → otimização de equipe → confirmação pelo PMO → dossiê da equipe aprovado. A busca exata preserva os elegíveis conhecidos no universo analisado; a semântica descobre terminologias e provas adicionais, sem excluir por baixa similaridade. O otimizador respeita vagas, papéis, datas, vínculos, capacidade, reutilização de provas e desempates aplicáveis; informa se demonstrou a maior nota.

O núcleo proposto é Java/Spring Boot e PostgreSQL, em monólito modular. Qwen auxilia extração/redação, Jev classifica questões semânticas e OR-Tools compõe equipes. **IA não decide autenticidade, não calcula a nota nem autoriza o envio.** Modelos indisponíveis ou resultados incertos geram revisão. A implantação começa com cadastro, regras e processo enxutos; componentes adicionais precisam demonstrar benefício.

No cenário sintético, uma escolha isolada soma **30 pontos**. A composição conjunta chega a **31**, sem duplicar pessoas nem usar o profissional indisponível. A recuperação e aprovação de dois atestados de Carla elevam a melhor composição para **35**. Antes da comprovação, o sistema mantém 31 confirmados e 35 apenas como cenário condicionado. A memória de cálculo e todas as combinações desse exemplo foram conferidas; o caso não é evidência de ganho em uma licitação real.

## 4. Impacto, riscos e implantação

O piloto medirá horas de todas as áreas e colaboradores, falsos atendimentos, provas recuperadas, conflitos de agenda e custo por proposta. **Redução líquida de 40% das horas seria 240–400 horas anuais liberadas**, hipótese ainda não medida. O custo total inclui preparação inicial, desenvolvimento, infraestrutura, integrações, manutenção e revisão, sem repetir esforço. A comparação inclui oportunidades não concluídas e critérios de avanço definidos previamente. Se o custo superar o benefício, o escopo será reduzido. Não prometemos economia de caixa, aumento da taxa de vitória ou aprovação jurídica automática.

RH verifica provas; PMO confirma capacidade; Licitações valida critérios e dossiê. Aprovar ou exportar a parcela de equipe não significa entregar a proposta integral. Consulta e exportação têm permissões distintas, com versões e retenção controladas. API externa só recebe dados autorizados, minimizados e contratualmente avaliados. O protótipo utiliza dados sintéticos e identifica simulações. O piloto compara o processo manual em uma área, com editais históricos e corte de informação explícito.

Para manter a base viva, eventos de projetos/certificações geram rascunhos a confirmar e campanhas abertas descobrem competências desconhecidas, como Security+. Indicações internas e externas passam por aceite e verificação; externos não entram automaticamente no quadro. A gamificação reconhece contribuições validadas, sem ranking público por pessoa nem influência na nota técnica ou compra de prioridade em projetos.

## 5. Afinidade e perspectivas de cooperação EloGroup–CEFET-MG

A EloGroup integra tecnologia, analytics e gestão para transformar processos e capturar valor nos negócios, abordagem diretamente relacionada ao Aptus. O CEFET-MG reúne competências de formação e pesquisa em computação, engenharia de software, bancos de dados, inteligência artificial e pesquisa operacional que permitem transformar esse problema organizacional em uma solução verificável. A cooperação proposta combina o conhecimento da empresa sobre elaboração de propostas, documentação e gestão de pessoas com a capacidade acadêmica de modelar restrições, desenvolver sistemas, avaliar algoritmos e medir resultados. Um piloto supervisionado permitiria comparar o processo atual com a solução em editais históricos, respeitando confidencialidade e proteção de dados. A instituição contribuiria com prototipação, testes e análise crítica; a empresa, com critérios de aceitação, validação de processos e avaliação de viabilidade. As perspectivas incluem projetos de extensão, pesquisa aplicada e formação de estudantes em problemas reais de governança de inteligência artificial. A continuidade dependeria de instrumentos institucionais próprios, autorizações de acesso e definição de responsabilidades, sem pressupor transferência automática de propriedade intelectual ou disponibilidade gratuita de infraestrutura. [3,4]

## 6. Resultados e fontes

**Obtido nesta etapa:** especificação revisada, arquitetura, regras e cenário sintético conferido. **Previsto:** aplicação, integrações, benchmark dos modelos e resultados de piloto. A contribuição da equipe é a combinação do ciclo de evidências, otimização e recuperação documental, apoiada em tecnologias existentes.

[1] EloGroup. Case B — Nexora, material do desafio. [2] AMEP-PR. Ata técnica da Concorrência 02/2026, pp. 6–7: [documento oficial](https://www.amep.pr.gov.br/sites/comec/arquivos_restritos/files/documento/2026-05/ce_02-26_-_ata_de_julgamento_anexos_r02.pdf). [3] [EloGroup — apresentação institucional](https://elogroup.com/sobre-a-elogroup/). [4] [CEFET-MG/DECOM — disciplinas](https://www.decom.cefetmg.br/ensino/graduacao/engenharia-de-computacao/disciplinas/).
